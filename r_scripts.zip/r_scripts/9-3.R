# 程式碼 9-3
weather <- sample(c("sunny", "rainy"), size = 1) 
weather
if (weather == "sunny"){
    print("Running outdoors!") } 
else {
    print("Working out in the gym!")
}