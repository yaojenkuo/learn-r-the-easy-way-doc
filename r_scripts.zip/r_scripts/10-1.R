# 程式碼 10-1
# 自訂函數
my_squared <- function(x){
    y <- x^2
    return(y)
}
# 呼叫函數
my_squared(2)
my_squared(-2:2)