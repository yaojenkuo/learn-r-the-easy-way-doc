# 程式碼 9-6
for (month in month.name){
    if (month == "April"){
        break
    } else {
        print(month)
    }
}