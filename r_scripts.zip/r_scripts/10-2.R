# 程式碼 10-2
# 自訂函數
circle_area <- function(r){
    area <- pi * r^2 #R語言有內建圓周率pi
    return(area)
}
# 呼叫函數
circle_area(3)
circle_area(5)