# 程式碼 10-3
# 自訂函數
circle_circum <- function(r){
    circum <- 2 * pi * r #R 語言有內建圓周率 pi
    return(circum)
}
# 呼叫函數
circle_circum(3)
circle_circum(5)