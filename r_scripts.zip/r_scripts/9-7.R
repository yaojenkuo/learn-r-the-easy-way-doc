# 程式碼 9-7
for (month in month.name){
    if (month == "April"){
        next
    } else {
        print(month)
    }
}