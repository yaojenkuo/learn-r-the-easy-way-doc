# 程式碼 9-1
month.name # 1-12 月的月份名稱
month.name[1]
month.name[2]
month.name[3]
month.name[4]
month.name[5]
month.name[6]
month.name[7]
month.name[8]
month.name[9]
month.name[10]
month.name[11]
month.name[12]